package com.example.clicker_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ClickerController {

    @FXML
    private Label puntuacionLabel; // Etiqueta que muestra la puntuación

    @FXML
    private TextField puntuacionField; // Campo para mostrar la puntuación actual

    @FXML
    private Button gemasButton; // Botón "Gemas"

    @FXML
    private Button mejorarButton; // Botón "Mejorar Elemento Central"

    @FXML
    private ImageView img; // Referencia al ImageView de la imagen del pato

    private int puntuacion = 0; // Variable para almacenar la puntuación actual

    // Método que se llama al hacer clic en la imagen
    @FXML
    private void onImagenClick() {
        puntuacion += 50; // Incrementa la puntuación en 50 al hacer clic en la imagen
        actualizarPuntuacion();
    }

    // Método para actualizar la puntuación en la interfaz
    private void actualizarPuntuacion() {
        puntuacionField.setText(String.valueOf(puntuacion)); // Actualiza el campo de texto con la nueva puntuación
    }

    // Método que se llama al hacer clic en el botón "Gemas"
    @FXML
    private void gemasButton() {
        if (puntuacion >= 100) {
            puntuacion = puntuacion - 100; // Restar 100 puntos al hacer clic en "Gemas" si hay suficientes puntos
            actualizarPuntuacion();
        } else {
            System.out.println("No tienes suficientes puntos para comprar una gema");
        }
    }

    // Método que se llama al hacer clic en el botón "Mejorar Elemento Central"
    @FXML
    private void mejorarButton() {
        // Cambiar la imagen por una nueva (asegúrate de que la ruta sea correcta)
       Image newImage = new Image("file:C:/Users/Natalia/Desktop/Clicker_fx/src/main/resources/com/example/clicker_fx/image_1.jpeg");
        //Image newImage = new Image("@img.jpeg");
        img.setImage(newImage);
    }
}