module com.example.clicker_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.clicker_fx to javafx.fxml;
    exports com.example.clicker_fx;
}