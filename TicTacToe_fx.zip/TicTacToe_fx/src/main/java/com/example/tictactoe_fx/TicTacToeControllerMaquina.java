package com.example.tictactoe_fx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.util.Random;

public class TicTacToeControllerMaquina {

    private static char[] tablero = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
    private static char jugadorActual = 'X';
    private boolean modoMaquina = false; // Indica si el juego es contra la máquina

    // Referencias a los botones en el FXML
    @FXML private Button btn1;
    @FXML private Button btn2;
    @FXML private Button btn3;
    @FXML private Button btn4;
    @FXML private Button btn5;
    @FXML private Button btn6;
    @FXML private Button btn7;
    @FXML private Button btn8;
    @FXML private Button btn9;

    private Button[][] botones;

    // Inicializar el tablero de botones
    @FXML
    public void initialize() {
        botones = new Button[][]{
                {btn1, btn2, btn3},
                {btn4, btn5, btn6},
                {btn7, btn8, btn9}
        };
    }

    // Métodos para cada botón, deben coincidir con los eventos onAction del FXML
    @FXML
    private void clicked1(ActionEvent event) {
        manejarClic(0, 0);
    }

    @FXML
    private void clicked2(ActionEvent event) {
        manejarClic(0, 1);
    }

    @FXML
    private void clicked3(ActionEvent event) {
        manejarClic(0, 2);
    }

    @FXML
    private void clicked4(ActionEvent event) {
        manejarClic(1, 0);
    }

    @FXML
    private void clicked5(ActionEvent event) {
        manejarClic(1, 1);
    }

    @FXML
    private void clicked6(ActionEvent event) {
        manejarClic(1, 2);
    }

    @FXML
    private void clicked7(ActionEvent event) {
        manejarClic(2, 0);
    }

    @FXML
    private void clicked8(ActionEvent event) {
        manejarClic(2, 1);
    }

    @FXML
    private void clicked9(ActionEvent event) {
        manejarClic(2, 2);
    }

    @FXML
    private void maquina(ActionEvent event) {
        modoMaquina = true; // Activar el modo máquina
        reiniciarJuego(); // Reiniciar el juego para comenzar contra la máquina
        if (jugadorActual == 'O') {
            maquinaMovimiento(); // Si la máquina es el primer jugador, realiza su movimiento inicial
        }
    }

    // Método para manejar el clic en una casilla (botón)
    private void manejarClic(int fila, int columna) {
        if (tablero[fila * 3 + columna] != 'X' && tablero[fila * 3 + columna] != 'O') {
            tablero[fila * 3 + columna] = jugadorActual; // Marca el movimiento en el tablero lógico
            botones[fila][columna].setText(String.valueOf(jugadorActual)); // Pinta en el botón (X o O)
            comprobarGanador(); // Verificar si hay ganador o empate

            // Cambiar turno solo si el modo máquina no está activado
            if (modoMaquina && jugadorActual == 'X') {
                cambiarJugador(); // Cambia al jugador 'O' (la máquina)
                maquinaMovimiento(); // Realizar movimiento de la máquina
            } else {
                cambiarJugador(); // Cambiar turno normal entre dos jugadores
            }
        }
    }

    // Método para cambiar el turno del jugador
    private void cambiarJugador() {
        jugadorActual = (jugadorActual == 'X') ? 'O' : 'X';
    }

    // Método para comprobar el estado del juego (ganador o empate)
    private void comprobarGanador() {
        // Comprobar filas, columnas y diagonales
        for (int i = 0; i < 3; i++) {
            // Comprobar filas
            if (!botones[i][0].getText().isEmpty() &&
                    botones[i][0].getText().equals(botones[i][1].getText()) &&
                    botones[i][0].getText().equals(botones[i][2].getText())) {
                mostrarGanador(botones[i][0].getText());
                return;
            }
            // Comprobar columnas
            if (!botones[0][i].getText().isEmpty() &&
                    botones[0][i].getText().equals(botones[1][i].getText()) &&
                    botones[0][i].getText().equals(botones[2][i].getText())) {
                mostrarGanador(botones[0][i].getText());
                return;
            }
        }

        // Comprobar diagonales
        if (!botones[0][0].getText().isEmpty() &&
                botones[0][0].getText().equals(botones[1][1].getText()) &&
                botones[0][0].getText().equals(botones[2][2].getText())) {
            mostrarGanador(botones[0][0].getText());
            return;
        }

        if (!botones[0][2].getText().isEmpty() &&
                botones[0][2].getText().equals(botones[1][1].getText()) &&
                botones[0][2].getText().equals(botones[2][0].getText())) {
            mostrarGanador(botones[0][2].getText());
            return;
        }

        // Comprobar empate (si todas las casillas están llenas y no hay ganador)
        boolean empate = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (botones[i][j].getText().isEmpty()) {
                    empate = false;
                    break;
                }
            }
        }
        if (empate) {
            mostrarEmpate();
        }
    }

    // Mostrar mensaje de ganador y reiniciar juego
    private void mostrarGanador(String ganador) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fin del juego");
        alert.setHeaderText(null);
        alert.setContentText("¡El ganador es " + ganador + "!");
        alert.showAndWait();
        reiniciarJuego();
    }

    // Mostrar mensaje de empate y reiniciar juego
    private void mostrarEmpate() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fin del juego");
        alert.setHeaderText(null);
        alert.setContentText("¡Es un empate!");
        alert.showAndWait();
        reiniciarJuego();
    }

    // Reiniciar el juego
    private void reiniciarJuego() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                botones[i][j].setText("");
                tablero[i * 3 + j] = (char) ('1' + i * 3 + j);
            }
        }
        jugadorActual = 'X'; // Reiniciar el jugador actual
    }

    // Movimiento de la máquina
    private void maquinaMovimiento() {
        Random rand = new Random();
        int fila, columna;

        // Buscar una casilla vacía aleatoriamente
        do {
            fila = rand.nextInt(3);
            columna = rand.nextInt(3);
        } while (!botones[fila][columna].getText().isEmpty());

        // Realizar movimiento de la máquina
        botones[fila][columna].setText("O");
        tablero[fila * 3 + columna] = 'O';

        comprobarGanador(); // Comprobar si la máquina ganó
        cambiarJugador(); // Volver al turno del jugador
    }
}
