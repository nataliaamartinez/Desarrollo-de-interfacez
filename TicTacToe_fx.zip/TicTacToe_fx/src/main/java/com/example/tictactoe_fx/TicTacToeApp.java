package com.example.tictactoe_fx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;


public class TicTacToeApp extends Application {
    private static Scene scene;

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Tic Tac Toe");

        // Cargar el archivo FXML con la ruta correcta
        scene = new Scene(loadFXML("TICTACTOEMaquina"), 450, 400);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Método para cargar el archivo FXML
    private Parent loadFXML(String fxml) throws IOException {
        // Corregir la ruta para que coincida con el paquete actual
        FXMLLoader fxmlLoader = new FXMLLoader(TicTacToeApp.class.getResource("/com/example/tictactoe_fx/" + fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch(args);
    }
}