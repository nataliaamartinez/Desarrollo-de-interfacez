package com.example.imgconslider;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SliderApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {

        // Cargar el archivo FXML
        Parent root = FXMLLoader.load(getClass().getResource("SLIDER.fxml"));

        // Crear la escena y asignarla al escenario
        Scene scene = new Scene(root, 600, 400);

        // Configurar el escenario
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
