package com.example.imgconslider;

import javafx.fxml.FXML;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class SliderController {
    @FXML
    private double tamanoOriginal;


    @FXML
    private ImageView imagen;

    @FXML
    private Slider controlSlider;

    // Método para inicializar la imagen
    @FXML
    public void initialize() {

        Image imagen = new Image("file:C:/Users/Natalia/Desktop/ImgConSlider/src/main/resources/com/example/imgconslider/dog-2606759_1280.jpg");  // Cambia esto a la ruta real

        this.imagen.setImage(imagen);


        controlSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            this.imagen.setFitWidth(newValue.doubleValue()); // Cambiar el ancho de la imagen
        });
    }
    // Método para aplicar el cambio de tamoño  con el Slider
    @FXML
    public void aplicarEscala() {
        double valorEscala = controlSlider.getValue();
        imagen.setFitWidth(valorEscala); // Ajustar el ancho de la imagen
    }

    // Método para restablecer el tamaño original cuando se presiona el botón
    @FXML
    private void restablecerTamanoOriginal() {
        imagen.setFitWidth(tamanoOriginal);  // Restablecer el tamaño original
        controlSlider.setValue(tamanoOriginal);  // También mover el slider al valor original
    }
}