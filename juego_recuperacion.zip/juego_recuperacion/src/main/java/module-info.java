module com.example.juego_recuperacion {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.juego_recuperacion to javafx.fxml;
    exports com.example.juego_recuperacion;
}