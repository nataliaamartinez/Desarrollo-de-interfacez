package com.example.juego_recuperacion;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.event.ActionEvent;

public class TableroController {
    @FXML
    private GridPane tablero;

    @FXML
    private Label contador;

    @FXML
    private Button reiniciar;

    private Button[][] botones;
    private int casillaEspecialX;
    private int casillaEspecialY;
    private int contadorClicks = 0;

    private static final int FILAS = 5;
    private static final int COLUMNAS = 6;

    @FXML
    public void initialize() {
        botones = new Button[FILAS][COLUMNAS];
        crearTablero();
        generarCasillaEspecial();
        actualizarContador();
    }

    private void crearTablero() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                Button boton = new Button();
                boton.setPrefSize(60, 60);
                boton.setOnAction(this::onBotonClick);
                botones[i][j] = boton;
                tablero.add(boton, j, i + 1);
            }
        }
    }

    private void onBotonClick(ActionEvent event) {
        Button boton = (Button) event.getSource();
        manejarClick(boton);
    }

    private void generarCasillaEspecial() {
        casillaEspecialX = (int) (Math.random() * FILAS);
        casillaEspecialY = (int) (Math.random() * COLUMNAS);
    }

    private void manejarClick(Button boton) {
        int fila = GridPane.getRowIndex(boton) - 1;
        int columna = GridPane.getColumnIndex(boton);
        contadorClicks++;

        if (fila == casillaEspecialX && columna == casillaEspecialY) {
            mostrarMensajeVictoria();
        } else {
            int distancia = calcularDistancia(fila, columna);
            boton.setText(String.valueOf(distancia));
        }

        actualizarContador();
    }

    private int calcularDistancia(int fila, int columna) {
        return Math.abs(fila - casillaEspecialX) + Math.abs(columna - casillaEspecialY);
    }

    private void actualizarContador() {
        contador.setText("casillas pulsadas: " + contadorClicks);
    }

    @FXML
    private void reiniciarJuego() {
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                botones[i][j].setText("");
            }
        }
        contadorClicks = 0;
        actualizarContador();
        generarCasillaEspecial();
    }

    private void mostrarMensajeVictoria() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("victoria!");
        alert.setHeaderText(null);
        alert.setContentText("felicidades, has encontrado la casilla especial!");
        alert.showAndWait();
        reiniciarJuego();
    }
}
