package com.example.buscaminas;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

import java.util.Random;

public class TableroController {

    private final int tamaño = 10;  // Tamaño del tablero (10x10)
    private final int MINES = 10; // Número de minas
    private Button[][] buttons = new Button[tamaño][tamaño];
    private boolean[][] mines = new boolean[tamaño][tamaño];

    @FXML
    private GridPane gridPane;  // Conectar con el GridPane en el FXML

    @FXML
    public void initialize() {
        generarTablero();
        colocarMinas();
    }

    private void generarTablero() {
        for (int row = 0; row < tamaño; row++) {
            for (int col = 0; col < tamaño; col++) {
                Button btn = new Button();
                btn.setPrefSize(40, 40);
                final int r = row;
                final int c = col;

                // Al hacer clic en una celda
                btn.setOnAction(e -> manejarClick(r, c));

                buttons[row][col] = btn;
                gridPane.add(btn, col, row);  // Añadir el botón al GridPane
            }
        }
    }

    private void colocarMinas() {
        Random random = new Random();
        int placedMines = 0;

        while (placedMines < MINES) {
            int row = random.nextInt(tamaño);
            int col = random.nextInt(tamaño);

            if (!mines[row][col]) {
                mines[row][col] = true;
                placedMines++;
            }
        }
    }

    private void manejarClick(int row, int col) {
        if (mines[row][col]) {
            mostrarPerdiste();
            descubrirTablero();
        } else {
            int minasCerca = contarMinasAlrededor(row, col);
            buttons[row][col].setText(String.valueOf(minasCerca));
            buttons[row][col].setDisable(true);
        }
    }

    private int contarMinasAlrededor(int row, int col) {
        int count = 0;
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                int r = row + i;
                int c = col + j;
                if (r >= 0 && r < tamaño && c >= 0 && c < tamaño && mines[r][c]) {
                    count++;
                }
            }
        }
        return count;
    }

    private void descubrirTablero() {
        for (int row = 0; row < tamaño; row++) {
            for (int col = 0; col < tamaño; col++) {
                if (mines[row][col]) {
                    buttons[row][col].setText("X");
                }
                buttons[row][col].setDisable(true);
            }
        }
    }

    private void mostrarPerdiste() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fin del Juego");
        alert.setHeaderText(null);
        alert.setContentText("¡Perdiste! Has hecho clic en una mina.");
        alert.showAndWait();
    }
}