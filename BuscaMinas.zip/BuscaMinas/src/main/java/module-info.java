module com.example.buscaminas {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.buscaminas to javafx.fxml;
    exports com.example.buscaminas;
}