module com.example.formulario_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.formulario_fx to javafx.fxml;
    exports com.example.formulario_fx;
}