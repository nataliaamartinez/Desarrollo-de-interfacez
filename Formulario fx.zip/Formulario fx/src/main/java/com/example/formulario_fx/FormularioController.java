package com.example.formulario_fx;


import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FormularioController {

    @FXML
    private TextField txtNombre, txtApellidos, txtCorreo, txtTelefono, txtCuota;
    @FXML
    private DatePicker dpFechaNacimiento;
    @FXML
    private RadioButton rbMasculino, rbFemenino, rbSoltero, rbCasado;
    @FXML
    private CheckBox cbCarnet;
    @FXML
    private ComboBox<String> cbProfesion;

    @FXML
    private ToggleGroup sexoGroup, estadoCivilGroup;
    @FXML
    private Button buttonEnviar;

    @FXML
    public void initialize() {
        // Inicializamos el ComboBox con algunas profesiones
        cbProfesion.getItems().addAll("Ingeniero", "Doctor", "Abogado", "Profesor", "Otro");

        // Grupo de botones para Sexo
        sexoGroup = new ToggleGroup();
        rbMasculino.setToggleGroup(sexoGroup);
        rbFemenino.setToggleGroup(sexoGroup);

        // Grupo de botones para Estado Civil
        estadoCivilGroup = new ToggleGroup();
        rbSoltero.setToggleGroup(estadoCivilGroup);
        rbCasado.setToggleGroup(estadoCivilGroup);
    }

    @FXML
    public void onAddUser() {
        String errores = validarFormulario();
        if (!errores.isEmpty()) {
            mostrarAlerta("Errores en el formulario", errores);
            return;
        }

        // Si los datos son correctos, guardamos el usuario
        guardarUsuario();
        mostrarAlerta("Usuario añadido", "Usuario añadido correctamente al archivo CSV");
        limpiarFormulario();
    }

    private String validarFormulario() {
        StringBuilder errores = new StringBuilder();

        if (txtNombre.getText().trim().isEmpty()) {
            errores.append("Nombre es obligatorio.\n");
        }
        if (txtApellidos.getText().trim().isEmpty()) {
            errores.append("Apellidos son obligatorios.\n");
        }
        if (dpFechaNacimiento.getValue() == null) {
            errores.append("Fecha de nacimiento es obligatoria.\n");
        }
        if (!txtCorreo.getText().contains("@")) {
            errores.append("Correo electrónico no es válido.\n");
        }
        if (!txtTelefono.getText().matches("\\d{9}")) {
            errores.append("Teléfono debe contener 9 dígitos.\n");
        }
        if (!txtCuota.getText().matches("\\d+(\\.\\d{1,2})?")) {
            errores.append("Cuota debe ser un número válido.\n");
        }
        if (sexoGroup.getSelectedToggle() == null) {
            errores.append("Debe seleccionar un sexo.\n");
        }
        if (estadoCivilGroup.getSelectedToggle() == null) {
            errores.append("Debe seleccionar un estado civil.\n");
        }
        if (cbProfesion.getSelectionModel().getSelectedItem() == null) {
            errores.append("Debe seleccionar una profesión.\n");
        }

        return errores.toString();
    }

    private void guardarUsuario() {
        if (cbCarnet == null) {
            return; // Detenemos el método si cbCarnet es nulo
        }
        // Obtener los datos
        String nombre = txtNombre.getText();
        String apellidos = txtApellidos.getText();
        LocalDate fechaNacimiento = dpFechaNacimiento.getValue();
        String correo = txtCorreo.getText();
        String telefono = txtTelefono.getText();
        String cuota = txtCuota.getText();
        String sexo = ((RadioButton) sexoGroup.getSelectedToggle()).getText();
        String estadoCivil = ((RadioButton) estadoCivilGroup.getSelectedToggle()).getText();
        String carnet = cbCarnet.isSelected() ? "Sí" : "No";
        String profesion = cbProfesion.getValue();

        // Formatear los datos para el CSV
        String usuario = String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
                nombre, apellidos, fechaNacimiento != null ? fechaNacimiento.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "",
                correo, telefono, cuota, sexo, estadoCivil, carnet, profesion);

        // Guardar en archivo CSV
        try (FileWriter fw = new FileWriter("usuarios.csv", true)) {
            fw.write(usuario);
            System.out.println("Usuario guardado exitosamente en CSV");
        } catch (IOException e) {
            System.out.println("Error al guardar el archivo CSV: " + e.getMessage());
            mostrarAlerta("Error", "No se pudo guardar el usuario en el archivo.");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void limpiarFormulario() {
        txtNombre.clear();
        txtApellidos.clear();
        dpFechaNacimiento.setValue(null);
        txtCorreo.clear();
        txtTelefono.clear();
        txtCuota.clear();
        sexoGroup.selectToggle(null);
        estadoCivilGroup.selectToggle(null);
        cbCarnet.setSelected(false);
        cbProfesion.getSelectionModel().clearSelection();
    }
}
