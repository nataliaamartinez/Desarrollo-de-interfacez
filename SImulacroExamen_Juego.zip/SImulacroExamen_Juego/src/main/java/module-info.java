module com.example.simulacroexamen_juego {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.simulacroexamen_juego to javafx.fxml;
    exports com.example.simulacroexamen_juego;
}