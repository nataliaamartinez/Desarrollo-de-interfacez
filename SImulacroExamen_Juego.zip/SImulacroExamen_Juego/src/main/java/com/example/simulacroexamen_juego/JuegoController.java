package com.example.simulacroexamen_juego;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.util.*;

public class JuegoController {
    @FXML
    private GridPane gridPane;
    @FXML
    private List<Image> imagenes; // Lista de imágenes para el juego
    @FXML
    private List<Button> botones; // Botones del tablero
    @FXML
    private Button primerBoton = null;
    @FXML
    private Button segundoBoton = null;
    @FXML
    private long tiempoInicio;
    @FXML
    private ImageView primeraSeleccionada = null;
    @FXML
    private ImageView segundaSeleccionada = null;
    @FXML
    private boolean esperando = false; // Para evitar que se hagan más clics mientras se espera

    // Imagen que se usa como "oculta"
    private final Image imagenOculta = new Image(getClass().getResource("/images/imagen_oculta.png").toExternalForm());


    @FXML
    public void initialize() {
        cargarImagenes();
        inicializarTablero();
        tiempoInicio = System.nanoTime(); // Iniciar el cronómetro
    }

    // Cargar las imágenes (8 parejas en total)
    private void cargarImagenes() {
        imagenes = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            Image img = new Image(getClass().getResourceAsStream("/imagenes/imagen" + i + ".png"));
            imagenes.add(img);
            imagenes.add(img); // Añadir las parejas
        }
        Collections.shuffle(imagenes); // Mezclar la lista
    }

    // Inicializar el tablero con botones
    private void inicializarTablero() {
        botones = new ArrayList<>();

        for (int i = 0; i < 16; i++) {
            Button boton = new Button();
            boton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("/imagenes/oculta.png"))));
            boton.setOnAction(e -> manejarClickBoton(boton));
            botones.add(boton);

            gridPane.add(boton, i % 4, i / 4); // Posicionar en la cuadrícula
        }
    }

    // Manejar el clic en un botón
    @FXML
    public void manejarClickBoton(Button event) {
        // Verificar si estamos esperando a ocultar imágenes (evitar múltiples clics)
        if (esperando) {
            return;
        }
        // Si la imagen ya está visible, no hacer nada
        ImageView imagenSeleccionada = new ImageView();
        if (imagenSeleccionada.getImage() != imagenOculta) {
            return;
        }

        // Mostrar la imagen (la que está "detrás")
        imagenSeleccionada.setImage(new Image(getClass().getResource(imagenSeleccionada.getId()).toExternalForm()));

        // Si no hay ninguna imagen seleccionada, esta es la primera selección
        if (primeraSeleccionada == null) {
            primeraSeleccionada = imagenSeleccionada;
        } else {
            // Esta es la segunda selección
            segundaSeleccionada = imagenSeleccionada;

            // Verificar si las imágenes seleccionadas son iguales
            if (primeraSeleccionada.getId().equals(segundaSeleccionada.getId())) {
                // Las imágenes coinciden, dejarlas visibles
                primeraSeleccionada = null;
                segundaSeleccionada = null;
            } else {
                // Las imágenes no coinciden, volver a ocultarlas después de un breve tiempo
                esperando = true;

                // Usar un temporizador para dar tiempo antes de ocultarlas
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        Platform.runLater(() -> {
                            primeraSeleccionada.setImage(imagenOculta);
                            segundaSeleccionada.setImage(imagenOculta);
                            primeraSeleccionada = null;
                            segundaSeleccionada = null;
                            esperando = false; // Ya no estamos esperando, podemos seguir jugando
                        });
                    }
                }, 1000); // Esperar 1 segundo antes de ocultar las imágenes
            }
        }
    }

    // Mostrar la imagen asociada a un botón
    private void mostrarImagen(Button boton) {
        int indice = botones.indexOf(boton);
        boton.setGraphic(new ImageView(imagenes.get(indice)));
    }

    // Verificar si las dos imágenes seleccionadas coinciden
    private void verificarPareja() {
        if (primerBoton.getGraphic().equals(segundoBoton.getGraphic())) {
            // Las imágenes coinciden
            primerBoton = null;
            segundoBoton = null;
            if (todasLasParejasEncontradas()) {
                mostrarMensajeFinal();
            }
        } else {
            // Las imágenes no coinciden, ocultarlas después de un retraso
            new Thread(() -> {
                try {
                    Thread.sleep(1000); // Esperar 1 segundo
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                ocultarImagenes();
            }).start();
        }
    }

    // Ocultar las imágenes de los botones seleccionados
    private void ocultarImagenes() {
        primerBoton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("/imagenes/oculta.png"))));
        segundoBoton.setGraphic(new ImageView(new Image(getClass().getResourceAsStream("/imagenes/oculta.png"))));
        primerBoton = null;
        segundoBoton = null;
    }

    // Comprobar si todas las parejas han sido encontradas
    // Comprobar si todas las parejas han sido encontradas
    private boolean todasLasParejasEncontradas() {
        Image imagenOculta = new Image(getClass().getResourceAsStream("/imagenes/oculta.png"));

        for (Button boton : botones) {
            ImageView graphic = (ImageView) boton.getGraphic();
            if (graphic.getImage().getUrl().equals(imagenOculta.getUrl())) {
                return false; // Si algún botón aún tiene la imagen oculta, no todas las parejas se han encontrado
            }
        }
        return true;
    }


    // Mostrar un mensaje de finalización con el tiempo
    private void mostrarMensajeFinal() {
        long tiempoFinal = System.nanoTime();
        long duracion = (tiempoFinal - tiempoInicio) / 1_000_000_000; // Tiempo en segundos
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("¡Juego completado!");
        alerta.setHeaderText(null);
        alerta.setContentText("¡Felicidades! Has completado el juego en " + duracion + " segundos.");
        alerta.show();
    }
}

