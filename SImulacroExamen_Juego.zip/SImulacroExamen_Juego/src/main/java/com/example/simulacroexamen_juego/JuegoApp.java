package com.example.simulacroexamen_juego;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class JuegoApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        // Cargar el archivo FXML
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("simulacroExamenJuego.fxml"));

        // Cargar la interfaz
        Parent root = fxmlLoader.load();

        // Crear la escena y mostrarla
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Juego de Memoria");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}