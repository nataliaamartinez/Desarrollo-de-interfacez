module com.example.calculadora_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.calculadora_fx to javafx.fxml;
    exports com.example.calculadora_fx;
}