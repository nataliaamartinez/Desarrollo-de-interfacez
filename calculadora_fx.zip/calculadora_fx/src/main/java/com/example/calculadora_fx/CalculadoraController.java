package com.example.calculadora_fx;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class CalculadoraController {
    @FXML
    private Label resultLabel; // Label para mostrar el resultado

    private double primerOperador = 0; // Primer operando
    private String operador = ""; // Operador actual
    private boolean empezar = true; // Indica si se está comenzando una nueva entrada

    // Método para manejar los clics en los botones numéricos y el punto
    @FXML
    private void onClickNumero(javafx.event.ActionEvent event) {
        String value = ((Button) event.getSource()).getText(); // Obtener el texto del botón clicado

        // Si se está comenzando una nueva operación, limpia el resultado
        if (empezar) {
            resultLabel.setText("");
            empezar = false;
        }

        // Agrega el valor clicado al label de resultado
        if (resultLabel.getText().equals("0")) { // Evitar que se muestre un cero innecesario
            resultLabel.setText(value);
        } else {
            resultLabel.setText(resultLabel.getText() + value);
        }
    }

    // Método para manejar los clics en los botones de operadores
    @FXML
    private void onClickOperador(javafx.event.ActionEvent event) {
        String value = ((Button) event.getSource()).getText(); // Obtener el texto del botón clicado

        if (!value.equals("=")) {
            // Guarda el operador y el primer operando
            if (!operador.isEmpty()) {
                return; // Si ya hay un operador, no hace nada
            }

            operador = value; // Almacena el operador
            primerOperador = Double.parseDouble(resultLabel.getText()); // Almacena el primer operando
            resultLabel.setText(""); // Limpia el display para el segundo operando
        } else {
            // Si no hay operador, no hace nada
            if (operador.isEmpty()) {
                return; // No se puede calcular sin un operador
            }

            // Realiza la operación y muestra el resultado
            double secondOperand = Double.parseDouble(resultLabel.getText());
            double result = calcular(primerOperador, secondOperand, operador);

            resultLabel.setText(String.valueOf(result)); // Muestra el resultado
            operador = ""; // Resetea el operador
            empezar = true; // Indica que se puede comenzar una nueva entrada
        }
    }

    // Método para manejar el clic en el botón "C" (clear)
    @FXML
    private void onClickLimpiar() {
        resultLabel.setText("0"); // Resetea el label
        primerOperador = 0; // Resetea el primer operando
        operador = ""; // Resetea el operador
        empezar = true; // Indica que se puede comenzar una nueva entrada
    }

    // Método para realizar el cálculo basado en el operador
    private double calcular(double num1, double num2, String operador) {
        switch (operador) {
            case "+":
                return num1 + num2;
            case "-":
                return num1 - num2;
            case "X":
                return num1 * num2;
            case "/":
                if (num2 == 0) {
                    return 0; // Evitar la división por cero
                }
                return num1 / num2;
            default:
                return 0;
        }
    }
}

