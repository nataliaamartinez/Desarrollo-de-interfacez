package com.example.loguin_fx;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;


public class LoguinController {
    @FXML
    private TextField nombreLogin;

    @FXML
    private PasswordField passwordLogin;

    private final String RUTA_ARCHIVO = "usuarios.txt"; // Archivo donde se guardan los usuarios

    // Método que maneja el inicio de sesión cuando el usuario pulsa el botón de "Login"
    @FXML
    private void loguearUsuario() {
        // Obtiene los valores ingresados por el usuario
        String nombre = nombreLogin.getText();
        String password = passwordLogin.getText();

        // Validaciones básicas
        if (nombre.isEmpty() || password.isEmpty()) {
            mostrarAlerta("Error", "Todos los campos son obligatorios.", Alert.AlertType.ERROR);
            return;
        }

        // Cargar los usuarios registrados desde el archivo
        Map<String, String> usuarios = cargarUsuarios();

        // Verificar si el usuario y la contraseña existen en el archivo
        if (usuarios.containsKey(nombre) && usuarios.get(nombre).equals(password)) {
            mostrarAlerta("Éxito", "Inicio de sesión correcto.", Alert.AlertType.INFORMATION); // Mensaje de éxito
            // Aquí podrías redirigir a una nueva pantalla después de un inicio de sesión exitoso
        } else if (!usuarios.containsKey(nombre)) {
            mostrarAlerta("Error", "Usuario no registrado. Por favor, regístrese antes.", Alert.AlertType.ERROR); // Usuario no encontrado
        } else {
            mostrarAlerta("Error", "Nombre o contraseña incorrectos.", Alert.AlertType.ERROR); // Contraseña incorrecta
        }
    }

    // Método para cargar los usuarios desde el archivo "usuarios.txt"
    private Map<String, String> cargarUsuarios() {
        Map<String, String> usuarios = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(RUTA_ARCHIVO))) {
            String linea;
            // Leer cada línea del archivo y extraer el nombre y la contraseña
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(":");
                if (partes.length == 2) {
                    usuarios.put(partes[0], partes[1]); // Guardar el nombre y la contraseña en el mapa
                }
            }
        } catch (IOException e) {
            mostrarAlerta("Error", "No se pudo cargar el archivo de usuarios.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }

        return usuarios; // Retornar el mapa con los usuarios cargados
    }

    // Método para mostrar alertas en pantalla
    private void mostrarAlerta(String titulo, String contenido, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(contenido);
        alerta.showAndWait();
    }

    // Método que se llama para lanzar la pantalla de registro
    @FXML
    private void llamadaPrimaria() throws IOException {
        // Cambia la vista a la pantalla de registro
        Login_Registrer_App.setRoot("REGISTRER");
    }
}