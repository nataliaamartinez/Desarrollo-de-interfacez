package com.example.loguin_fx;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class RegistrerController {
    @FXML
    private TextField nombreRegistro;

    @FXML
    private PasswordField passwordRegistro;

    @FXML
    private PasswordField repetirPasswordRegistro;

    private final String RUTA_ARCHIVO = "usuarios.txt"; // Archivo de texto para almacenar los datos de los usuarios

    // Método que maneja la acción al pulsar el botón "Registrarse"
    @FXML
    private void registrarUsuario() {
        // Obtener los valores del formulario
        String nombre = nombreRegistro.getText();
        String password = passwordRegistro.getText();
        String repetirPassword = repetirPasswordRegistro.getText();

        // Validaciones básicas
        if (nombre.isEmpty() || password.isEmpty() || repetirPassword.isEmpty()) {
            mostrarAlerta("Error", "Todos los campos son obligatorios.", Alert.AlertType.ERROR);
            return;
        }

        if (!password.equals(repetirPassword)) {
            mostrarAlerta("Error", "Las contraseñas no coinciden.", Alert.AlertType.ERROR);
            return;
        }

        // Guardar los datos del usuario en un archivo de texto plano
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_ARCHIVO, true))) {
            bw.write(nombre + ";" + password); // Guardar el nombre y la contraseña separados por ":"
            bw.newLine(); // Saltar a la siguiente línea
            mostrarAlerta("Éxito", "Usuario registrado correctamente.", Alert.AlertType.INFORMATION);
        } catch (IOException e) {
            mostrarAlerta("Error", "No se pudo guardar el usuario.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    // Método para mostrar alertas en pantalla
    private void mostrarAlerta(String titulo, String contenido, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(contenido);
        alerta.showAndWait();
    }

    // Método para manejar el botón que lanza la pantalla de login
    @FXML
    private void botonLogin() throws IOException {
        lanzarSegundaPantalla(); // Llama a este método para cambiar a la pantalla de login
    }

    // Método que lanza la segunda pantalla (Login)
    @FXML
    private void lanzarSegundaPantalla() throws IOException {
        Login_Registrer_App.setRoot("LOGIN"); // Cambia a la escena de login
    }
    @FXML
    private void irARegistro() throws IOException {
        // Cambiar la vista a la pantalla de registro (REGISTRER.fxml)
        Login_Registrer_App.setRoot("REGISTRER");
    }
}
