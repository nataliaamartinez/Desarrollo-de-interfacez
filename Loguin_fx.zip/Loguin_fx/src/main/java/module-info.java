module com.example.loguin_fx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.loguin_fx to javafx.fxml;
    exports com.example.loguin_fx;
}