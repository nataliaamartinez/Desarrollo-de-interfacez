module com.example.simulacro_examen {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.simulacro_examen to javafx.fxml;
    exports com.example.simulacro_examen;
}