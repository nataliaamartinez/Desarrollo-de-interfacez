package com.example.simulacro_examen;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class SimulacroFormController {
    @FXML
    private TextField nombre;

    @FXML
    private DatePicker fechaNacimiento;

    @FXML
    private CheckBox soltero;

    @FXML
    private CheckBox casado;

    @FXML
    private CheckBox dadoAlta;

    @FXML
    private Button guardarButton;

    @FXML
    private Button resetButton;

    @FXML
    private void guardarDatos() {
        String nombreUsuario = nombre.getText();
        String fecha = (fechaNacimiento.getValue() != null) ? fechaNacimiento.getValue().toString() : "";
        boolean esSoltero = soltero.isSelected();
        boolean esCasado = casado.isSelected();
        boolean estaDadoAlta = dadoAlta.isSelected();

        if (nombreUsuario.isEmpty() || fecha.isEmpty()) {
            mostrarAlerta("Error", "Todos los campos son obligatorios.");
            return;
        }

        // Aquí se puede agregar la lógica de guardar los datos, como imprimir en consola o guardarlos en un archivo
        System.out.println("Nombre: " + nombreUsuario);
        System.out.println("Fecha de nacimiento: " + fecha);
        System.out.println("Soltero: " + esSoltero);
        System.out.println("Casado: " + esCasado);
        System.out.println("Dado de alta: " + estaDadoAlta);

        mostrarAlerta("Éxito", "Datos guardados correctamente.");
    }

    @FXML
    private void resetFormulario() {
        nombre.clear();
        fechaNacimiento.setValue(null);
        soltero.setSelected(false);
        casado.setSelected(false);
        dadoAlta.setSelected(false);
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
