package com.example.simulacro_examen;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class SimulacroController {
    @FXML
    private TextField nombreLogin;

    @FXML
    private PasswordField passwordLogin;

    private final String RUTA_ARCHIVO = "/Usuarios.csv"; // Archivo donde se guardan los usuarios

    // Método que maneja el inicio de sesión cuando el usuario pulsa el botón de "Login"
    @FXML
    private void loguearUsuario() {
        // Obtiene los valores ingresados por el usuario
        String nombre = nombreLogin.getText();
        String password = passwordLogin.getText();

        // Validaciones básicas: Si el nombre o la contraseña están vacíos
        if (nombre.isEmpty() || password.isEmpty()) {
            mostrarAlerta("Error", "Todos los campos son obligatorios.", Alert.AlertType.ERROR);
            return;
        }

        // Cargar los usuarios registrados desde el archivo CSV
        Map<String, String> usuarios = cargarUsuarios();
        // Asegurarse de cargar correctamente el archivo de recursos
        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("usuarios.csv")))) {
            String linea;
            // Leer cada línea del archivo y extraer el nombre y la contraseña
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    usuarios.put(partes[0].trim(), partes[1].trim()); // Guardar el nombre y la contraseña en el mapa
                }
            }
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo cargar el archivo de usuarios.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    // Método para cargar los usuarios desde el archivo "usuarios.csv"
    private Map<String, String> cargarUsuarios() {
        Map<String, String> usuarios = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(RUTA_ARCHIVO)))) {
            String linea;
            // Leer cada línea del archivo y extraer el nombre y la contraseña
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    usuarios.put(partes[0].trim(), partes[1].trim()); // Guardar el nombre y la contraseña en el mapa
                }
            }
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo cargar el archivo de usuarios.", Alert.AlertType.ERROR);
            e.printStackTrace();
        }

        return usuarios; // Retornar el mapa con los usuarios cargados
    }

    // Método para mostrar alertas en pantalla
    private void mostrarAlerta(String titulo, String contenido, Alert.AlertType tipo) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(contenido);
        alerta.showAndWait();
    }
}
