package com.example.ejercicio2_examen;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class Controller {
    private int[][] cuadrado = new int[3][3];
    private int contadorClicks = 0;

    @FXML
    private Button[][] botones;
    @FXML
    private Label etiquetaResultado;

    @FXML
    public void initialize() {
        botones = new Button[][]{
                {boton00, boton01, boton02},
                {boton10, boton11, boton12},
                {boton20, boton21, boton22}
        };
    }

    @FXML
    private Button boton00, boton01, boton02;
    @FXML
    private Button boton10, boton11, boton12;
    @FXML
    private Button boton20, boton21, boton22;

    @FXML
    protected void alHacerClickEnBoton(ActionEvent e) {
        Node nodo = (Node) e.getSource();

        // Obtener fila y columna directamente
        int fila = GridPane.getRowIndex(nodo);
        int columna = GridPane.getColumnIndex(nodo);

        // Incrementar el contador de clics y actualizar la cuadrícula
        cuadrado[fila][columna] = ++contadorClicks;

        // Comprobar victoria si el contador llega a 9
        if (contadorClicks == 9) {
            comprobarVictoria();
        }
    }
    private void comprobarVictoria() {
        int sumaMagica = 15;
        boolean gano = true;

        for (int i = 0; i < 3; i++) {
            int sumaFila = cuadrado[i][0] + cuadrado[i][1] + cuadrado[i][2];
            int sumaColumna = cuadrado[0][i] + cuadrado[1][i] + cuadrado[2][i];

            if (sumaFila != sumaMagica || sumaColumna != sumaMagica) {
                gano = false;
                break;
            }
        }

        int sumaDiagonal1 = cuadrado[0][0] + cuadrado[1][1] + cuadrado[2][2];
        int sumaDiagonal2 = cuadrado[0][2] + cuadrado[1][1] + cuadrado[2][0];

        if (sumaDiagonal1 != sumaMagica || sumaDiagonal2 != sumaMagica) {
            gano = false;
        }

        if (gano) {
            etiquetaResultado.setText("¡Ganaste!");
        } else {
            etiquetaResultado.setText("Error, vuelve a intentarlo.");
        }
    }

    @FXML
    protected void alHacerClickDeshacer() {
        contadorClicks--;
    }
}

