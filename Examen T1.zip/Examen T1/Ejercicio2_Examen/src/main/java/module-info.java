module com.example.ejercicio2_examen {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ejercicio2_examen to javafx.fxml;
    exports com.example.ejercicio2_examen;
}