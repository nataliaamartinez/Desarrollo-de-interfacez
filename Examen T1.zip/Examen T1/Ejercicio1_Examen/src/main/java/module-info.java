module com.example.ejercicio1_examen {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ejercicio1_examen to javafx.fxml;
    exports com.example.ejercicio1_examen;
}