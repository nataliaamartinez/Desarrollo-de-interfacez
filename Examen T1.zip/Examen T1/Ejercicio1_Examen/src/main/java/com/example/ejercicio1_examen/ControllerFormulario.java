package com.example.ejercicio1_examen;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;


import java.io.*;
import java.util.ArrayList;
import java.util.List;




public class ControllerFormulario {
    @FXML
    private TextField nombre;
    @FXML
    private TextField correo;
    @FXML
    private TextField edad;
    @FXML
    private RadioButton profesion;
    @FXML
    private CheckBox vip;

    private List<Usuario> usuarios = new ArrayList<>();
    private int currentIndex = 0;

    @FXML
    public void initialize() {
        cargarUsuariosDesdeCSV("usuarios.csv");
        if (!usuarios.isEmpty()) {
            mostrarUsuario(usuarios.get(0)); // Muestra el primer usuario por defecto
        }
    }

    @FXML
    protected void onNextButtonClick() {
        aplicarCambiosActuales(); // Guardamos los cambios antes de cambiar al siguiente usuario
        currentIndex = (currentIndex + 1) % usuarios.size();
        mostrarUsuario(usuarios.get(currentIndex));
    }

    @FXML
    protected void onPrevButtonClick() {
        aplicarCambiosActuales(); // Guardamos los cambios antes de cambiar al usuario anterior
        currentIndex = (currentIndex - 1 + usuarios.size()) % usuarios.size();
        mostrarUsuario(usuarios.get(currentIndex));
    }

    @FXML
    protected void onGuardarButtonClick() {
        aplicarCambiosActuales(); // Guardar cambios en el usuario actual en la lista
    }

    @FXML
    protected void onLogoutButtonClick() throws IOException {
        aplicarCambiosActuales();
        guardarUsuariosEnCSV("usuarios.csv");
    }

    private void cargarUsuariosDesdeCSV(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] datos = line.split(",");
                String nombre = datos[0];
                String correo = datos[1];
                int edad = Integer.parseInt(datos[2]);
                String profesion = datos[3];
                boolean vip = Boolean.parseBoolean(datos[4]);
                usuarios.add(new Usuario(nombre, correo, edad, profesion, vip));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mostrarUsuario(Usuario usuario) {
        nombre.setText(usuario.getNombre());
        correo.setText(usuario.getCorreo());
        edad.setText(String.valueOf(usuario.getEdad()));
        vip.setSelected(usuario.isVip());
    }

    // Método que guarda los cambios hechos en el formulario en el usuario actual
    private void aplicarCambiosActuales() {
        Usuario usuarioActual = usuarios.get(currentIndex);
        usuarioActual.setNombre(nombre.getText());
        usuarioActual.setCorreo(correo.getText());
        usuarioActual.setEdad(Integer.parseInt(edad.getText()));
        usuarioActual.setVip(vip.isSelected());
    }

    // Guardar todos los usuarios en el archivo CSV
    private void guardarUsuariosEnCSV(String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (Usuario usuario : usuarios) {
                String line = usuario.getNombre() + "," +
                        usuario.getCorreo() + "," +
                        usuario.getEdad() + "," +
                        usuario.getProfesion() + "," +
                        usuario.isVip();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}