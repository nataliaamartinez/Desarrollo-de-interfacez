package com.example.ejercicio1_examen;

public class Usuario {

        private String nombre;
        private String correo;
        private int edad;
        private String profesion;
        private boolean vip;

        public Usuario(String nombre, String correo, int edad, String profesion, boolean vip) {
            this.nombre = nombre;
            this.correo = correo;
            this.edad = edad;
            this.profesion = profesion;
            this.vip = vip;
        }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "nombre='" + nombre + '\'' +
                ", correo='" + correo + '\'' +
                ", edad=" + edad +
                ", profesion='" + profesion + '\'' +
                ", vip=" + vip +
                '}';
    }
}

