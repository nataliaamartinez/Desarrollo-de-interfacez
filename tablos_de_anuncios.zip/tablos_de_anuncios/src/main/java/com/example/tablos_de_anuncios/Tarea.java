package com.example.tablos_de_anuncios;

public class Tarea {
    private String titulo;
    private String descripcion;
    private String fecha;
    private boolean online;

    public Tarea() {
        this.titulo = "";
        this.descripcion = "";
        this.fecha = "";
        this.online = false;
    }

    // Getters y Setters

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    @Override
    public String toString() {
        return "Titulo: " + titulo + ", Descripcion: " + descripcion + ", Fecha: " + fecha + ", Online: " + (online ? "Sí" : "No");
    }

}
