package com.example.tablos_de_anuncios;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class Controller {

    @FXML
    private GridPane tablero;

    @FXML
    private Button btnMostrar, btnLimpiar, btnActualizar;

    private Tarea[][] tareas = new Tarea[4][6];  // Matriz de tareas (4 filas, 6 columnas)

    @FXML
    public void initialize() {
        // Inicializar las tareas vacías
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                tareas[i][j] = new Tarea();
                actualizarCeldas();
            }
        }
    }

    // Actualizar las celdas del tablero
    @FXML
    private void actualizarCeldas() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                Button btn = (Button) tablero.getChildren().get(i * 6 + j);
                String titulo = tareas[i][j].getTitulo();
                if (titulo.isEmpty()) {
                    btn.setText("Vacío");
                } else {
                    btn.setText(titulo);
                }
            }
        }
    }

    // Mostrar todas las tareas en consola
    @FXML
    private void mostrarTareas() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.println("Tarea (" + i + "," + j + "): " + tareas[i][j]);
            }
        }
    }

    // Limpiar todas las tareas
    @FXML
    private void limpiarTareas() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 6; j++) {
                tareas[i][j] = new Tarea();  // Reiniciar cada tarea
            }
        }
        actualizarCeldas();
    }

    // Editar tarea de una celda específica
    @FXML
    private void editarTarea(int fila, int columna) {
        // Mostrar un diálogo para editar la tarea
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Editar Tarea");
        alert.setHeaderText("Editar Tarea (" + fila + "," + columna + ")");

        TextField tituloInput = new TextField(tareas[fila][columna].getTitulo());
        TextArea descripcionInput = new TextArea(tareas[fila][columna].getDescripcion());
        TextField fechaInput = new TextField(tareas[fila][columna].getFecha());
        CheckBox onlineInput = new CheckBox("Online");
        onlineInput.setSelected(tareas[fila][columna].isOnline());

        alert.getDialogPane().setContent(tituloInput);
        alert.showAndWait().ifPresent(response -> {
            tareas[fila][columna].setTitulo(tituloInput.getText());
            tareas[fila][columna].setDescripcion(descripcionInput.getText());
            tareas[fila][columna].setFecha(fechaInput.getText());
            tareas[fila][columna].setOnline(onlineInput.isSelected());
            actualizarCeldas();
        });
    }
}

