module com.example.tablos_de_anuncios {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.tablos_de_anuncios to javafx.fxml;
    exports com.example.tablos_de_anuncios;
}