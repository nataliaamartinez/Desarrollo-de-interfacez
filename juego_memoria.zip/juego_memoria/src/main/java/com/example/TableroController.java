package com.example;

import java.util.ArrayList;
import java.util.Random;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;



public class TableroController {

    int FILAS = 4;
    int COLUMNAS = 4;
    int[][] matriz = new int[FILAS][COLUMNAS];
    int clickado1 = -1;
    int clickado2 = -1;
    ImageView imageClicked1;
    ImageView imageClicked2;
    int numclicks = 0;
    long startTime = 0;
    int contadorDescubiertas=0;


    @FXML
    GridPane padre;

    public TableroController(){
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                matriz[i][j] = -1;
            }
        }
        aleatorio();
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    @FXML
    public void initialize(){

        startTime = System.nanoTime();
        for (Object hijo : padre.getChildren().toArray()) {
            ImageView img = (ImageView) hijo;
            img.setImage( new Image("file:src\\main\\resources\\com\\example\\image_default.jpg"));
        }
    }

    private void aleatorio(){
        int max = 15;
        int min = 0;
        for (int i = 1; i < 9; i++) {
            int insertado = 0;
            while(insertado<2){
                Random rand = new Random();
                int posRandom = rand.nextInt((max - min) + 1) + min;
                if(matriz[posRandom/FILAS][posRandom%COLUMNAS] == -1){
                    matriz[posRandom/FILAS][posRandom%COLUMNAS] = i;
                    insertado++;
                }
            }

            


        }

    }

    private boolean comprobar(int pos1, int pos2){
        int valor1 = matriz[pos1/FILAS][pos1%COLUMNAS];
        int valor2 = matriz[pos2/FILAS][pos2%COLUMNAS];
        
        return valor1==valor2;
    }

    private void setImageByPos(ImageView img, int pos){
        int valor = matriz[pos/FILAS][pos%COLUMNAS];
        img.setImage(new Image("file:src\\main\\resources\\com\\example\\image"+valor+".jpg"));
    }

    public void imageClicked(MouseEvent event){
        ImageView img = (ImageView) event.getSource();
        int pos = Integer.parseInt(img.getId().split("g")[1]);
        setImageByPos(img, pos);
        System.out.println("clicked: " + pos);
        numclicks++;
        if(numclicks==1){
            clickado1 = pos;
            imageClicked1 = img;
        }
        if(numclicks==2){
            clickado2 = pos;
            imageClicked2 = img;
            if(!comprobar(clickado1, clickado2)){
                System.out.println("son distintas");
                //poner por defecto
                
                imageClicked1.setImage(new Image("file:src\\main\\resources\\com\\example\\image_default.jpg"));
                imageClicked2.setImage(new Image("file:src\\main\\resources\\com\\example\\image_default.jpg"));
            }else{
                contadorDescubiertas++;
            }

            if(contadorDescubiertas==8){
                Alert alerta = new Alert(AlertType.INFORMATION);
                long endTime = System.nanoTime();
                alerta.setContentText("HAS GANADO! en " + (endTime-startTime) + " nanoseconds");
                alerta.show();
            }
            clickado1=-1;
            imageClicked1 = null;
            imageClicked2 = null;
            clickado2=-1;
            numclicks=0;
        }
        
        

    }

}
