module com.example.proyecto_di {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens com.example.proyecto_di to javafx.fxml;
    exports com.example.proyecto_di;
}