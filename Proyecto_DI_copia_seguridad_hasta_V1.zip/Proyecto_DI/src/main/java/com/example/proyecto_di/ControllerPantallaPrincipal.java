package com.example.proyecto_di;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;

public class ControllerPantallaPrincipal {
    @FXML
    private ImageView profileImageView;
    @FXML
    private BorderPane borderPane;
    @FXML
    private Button facebookButton;
    @FXML
    private Button whatsappButton;
    @FXML
    private Button instagramButton;
    @FXML
    private Button twitterButton;
    @FXML
    private ImageView userImage;
    @FXML
    private Button closeButton;
    @FXML
    private Button exitButton;

    @FXML
    private BorderPane mainBorderPane;

    @FXML
    public void initialize() {
        mainBorderPane.setMinWidth(600);
        mainBorderPane.setPrefHeight(400);
        // Crear un círculo con el tamaño deseado
        Circle clip = new Circle(35, 35, 35); // Radio 75 para un tamaño de 150x150
        profileImageView.setClip(clip); // Asignar el círculo como clip
    }
    @FXML
    private  void vistaXML () throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("VistaXml.fxml"));
        mainBorderPane.setCenter(loader.load());
    }

    @FXML
    private void ventanaInformacion() throws IOException {
        App.setRoot("VentanaInformacion");
    }

    @FXML
    private void ventanaAyuda() throws IOException {
        App.setRoot("VentanaAyuda");
    }

    // Método para cerrar la aplicación
    @FXML
    private void cerrarAplicacion() {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();
    }

    // Método para abrir Facebook
    @FXML
    private void abrirFacebook() {
        abrirEnlace("https://www.facebook.com");
    }

    // Método para abrir WhatsApp
    @FXML
    private void abrirWhatsApp() {
        abrirEnlace("https://www.whatsapp.com");
    }

    // Método para abrir Instagram
    @FXML
    private void abrirInstagram() {
        abrirEnlace("https://www.instagram.com");
    }

    @FXML
    private void abrirTwitter() {
        abrirEnlace("https://www.twitter.com");
    }

    // Método de ayuda para abrir un enlace en el navegador
    private void abrirEnlace(String url) {
        try {
            java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

