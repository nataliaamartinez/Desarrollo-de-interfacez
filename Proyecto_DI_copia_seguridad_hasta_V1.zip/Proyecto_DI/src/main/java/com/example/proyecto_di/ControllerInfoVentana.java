package com.example.proyecto_di;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class ControllerInfoVentana {
    @FXML
    private Button cerrar;
    @FXML
    private void cerrarVentanaInfo() throws IOException {
        Stage stage = (Stage) cerrar.getScene().getWindow();
        App.setRoot("PantallaPrincipalProyecto");
    }
}
