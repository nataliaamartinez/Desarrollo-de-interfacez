package com.example.proyecto_di;

import javafx.fxml.FXML;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;


public class ControllerVistaXml {
    /* // Crear un FileChooser para seleccionar archivos XML
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Abrir Archivo XML");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Archivos XML", "*.xml")
        );*/

    @FXML
    private TreeView<String> TreeXML; // Vincula con el TreeView del archivo FXML

    @FXML
    private void xmlButton() {

        // Crear el elemento raíz para el TreeView
        TreeItem<String> elementoRaiz = new TreeItem<>("Tutoriales");
        elementoRaiz.setExpanded(true); // Mostrar todos los elementos por defecto

        // Crear la rama de Tutoriales Web
        TreeItem<String> ramaWeb = new TreeItem<>("Tutoriales Web");
        ramaWeb.getChildren().addAll(
                new TreeItem<>("Tutorial HTML"),
                new TreeItem<>("Tutorial HTML5"),
                new TreeItem<>("Tutorial CSS"),
                new TreeItem<>("Tutorial SVG")
        );

        // Crear la rama de Tutoriales Java
        TreeItem<String> ramaJava = new TreeItem<>("Tutoriales Java");
        ramaJava.getChildren().addAll(
                new TreeItem<>("Lenguaje Java"),
                new TreeItem<>("Colecciones en Java"),
                new TreeItem<>("Concurrencia en Java")
        );

        // Agregar las ramas al elemento raíz
        elementoRaiz.getChildren().addAll(ramaWeb, ramaJava);

        // Establecer el elemento raíz en el TreeView
        TreeXML.setRoot(elementoRaiz);
    }
}