package com.example.ideaexamn1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller {
    @FXML
    private TextField usuario;
    @FXML
    private void llamadaSegundaPantalla() throws IOException {
        // Carga el archivo FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("INFROMACION_USER.fxml"));

        // Establece el root a partir del archivo cargado
        Parent root = loader.load();

        // Obtiene el stage actual a partir de un nodo de la escena
        Stage stage = (Stage)  usuario.getScene().getWindow();

        // Crea una nueva escena con el nuevo root
        Scene scene = new Scene(root);

        // Establece la nueva escena en el stage
        stage.setScene(scene);

        // Muestra la nueva pantalla
        stage.show();
    }
}

