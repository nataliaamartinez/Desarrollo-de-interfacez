package com.example.ideaexamn1;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import java.util.List;
import java.util.Arrays;

public class User_Controller {

    @FXML
    private TextField nombreUsuarioField;

    @FXML
    private TextField correoField;

    @FXML
    private TextField telefonoField;

    @FXML
    private DatePicker fechaNacimientoPicker;

    @FXML
    private ComboBox<String> estadoLaboralComboBox;

    @FXML
    private CheckBox activadoCheckBox;

    private Stage stage;
    private Scene scene;

    @FXML
    public void inizialice(){
        // Agrega las opciones al ComboBox
        estadoLaboralComboBox.getItems().addAll("Estudiante", "Empleado", "Desempleado");
    }


    // Al hacer clic en el botón "SALIR Y GUARDAR"
    @FXML
    private void guardarYSalir(ActionEvent event) {
        try {
            // Obtener los datos del formulario
            String nombreUsuario = nombreUsuarioField.getText();
            String correo = correoField.getText();
            String telefono = telefonoField.getText();
            String fechaNacimiento = (fechaNacimientoPicker.getValue() != null) ? fechaNacimientoPicker.getValue().toString() : "";
            String estadoLaboral = estadoLaboralComboBox.getValue();
            String activado = activadoCheckBox.isSelected() ? "Sí" : "No";

            // Guardar los datos en un archivo CSV
            guardarEnCSV(Arrays.asList(nombreUsuario, correo, telefono, fechaNacimiento, estadoLaboral, activado));

            // Cerrar la aplicación
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para guardar los datos en un archivo CSV
    private void guardarEnCSV(List<String> datos) throws IOException {
        FileWriter writer = new FileWriter("datos_usuario.csv", true); // Archivo donde se guardan los datos
        writer.append(String.join(",", datos));
        writer.append("\n");
        writer.flush();
        writer.close();
    }

    // Al hacer clic en el botón "VOLVER"
    @FXML
    private void volver(ActionEvent event) {
        try {
            // Cargar la primera pantalla
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FORMILARIO.fxml"));
            Pane root = loader.load();

            // Establecer la escena anterior
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

