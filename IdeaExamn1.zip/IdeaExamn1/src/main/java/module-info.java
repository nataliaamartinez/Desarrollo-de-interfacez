module com.example.ideaexamn1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ideaexamn1 to javafx.fxml;
    exports com.example.ideaexamn1;
}